package me.obsidianbreaker.leux.client.manager;

import com.google.common.reflect.TypeToken;

public class ConfigManager$2 extends TypeToken {
  public ConfigManager this$0;
}
