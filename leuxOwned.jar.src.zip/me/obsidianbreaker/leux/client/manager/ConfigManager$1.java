package me.obsidianbreaker.leux.client.manager;

import com.google.common.reflect.TypeToken;

public class ConfigManager$1 extends TypeToken {
  public ConfigManager this$0;
}
