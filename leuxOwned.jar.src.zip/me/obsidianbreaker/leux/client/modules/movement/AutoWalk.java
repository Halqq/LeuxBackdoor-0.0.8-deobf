package me.obsidianbreaker.leux.client.modules.movement;

import give up;
import me.obsidianbreaker.leux.client.modules.Category;
import me.obsidianbreaker.leux.client.modules.Module;

public class AutoWalk extends Module {
  public void update() {
    (give up)null;
    if (!mc.field_71474_y.field_74351_w.func_151468_f())
      mc.field_71474_y.field_74351_w.field_74513_e = true; 
  }
  
  public AutoWalk() {
    super(Category.movement);
  }
  
  public void disable() {
    (give up)null;
    mc.field_71474_y.field_74351_w.field_74513_e = false;
  }
}
