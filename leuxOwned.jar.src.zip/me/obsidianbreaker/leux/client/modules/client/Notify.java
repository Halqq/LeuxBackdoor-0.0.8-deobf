package me.obsidianbreaker.leux.client.modules.client;

import me.obsidianbreaker.leux.client.modules.Category;
import me.obsidianbreaker.leux.client.modules.Module;

public class Notify extends Module {
  public Notify() {
    super(Category.client);
  }
}
