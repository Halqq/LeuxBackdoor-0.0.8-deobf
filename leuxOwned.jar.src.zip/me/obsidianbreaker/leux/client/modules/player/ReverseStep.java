package me.obsidianbreaker.leux.client.modules.player;

import give up;
import me.obsidianbreaker.leux.client.modules.Category;
import me.obsidianbreaker.leux.client.modules.Module;

public class ReverseStep extends Module {
  public void update() {
    (give up)null;
    if (!mc.field_71439_g.field_70122_E || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab() || mc.field_71439_g.field_71158_b.field_78901_c || mc.field_71439_g.field_70145_X)
      return; 
    if (mc.field_71439_g.field_191988_bg == 0.0F && mc.field_71439_g.field_70702_br == 0.0F)
      return; 
    mc.field_71439_g.field_70181_x = -1.0D;
  }
  
  public ReverseStep() {
    super(Category.player);
  }
}
