package me.obsidianbreaker.leux.client.modules.render;

import me.obsidianbreaker.leux.client.modules.Category;
import me.obsidianbreaker.leux.client.modules.Module;

public class ClearChat extends Module {
  public ClearChat() {
    super(Category.render);
  }
}
