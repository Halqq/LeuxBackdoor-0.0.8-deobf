package me.obsidianbreaker.leux.client.modules.combat;

import java.util.ArrayList;

public class CevBreaker$structureTemp {
  public double distance;
  
  public int direction;
  
  public ArrayList to_place;
  
  public int supportBlock;
  
  public CevBreaker$structureTemp(double paramDouble, int paramInt, ArrayList paramArrayList) {
    this.distance = paramDouble;
    this.supportBlock = paramInt;
    this.to_place = paramArrayList;
    this.direction = -1;
  }
}
