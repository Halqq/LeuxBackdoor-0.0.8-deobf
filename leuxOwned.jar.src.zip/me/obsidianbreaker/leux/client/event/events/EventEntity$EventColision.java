package me.obsidianbreaker.leux.client.event.events;

import give up;
import net.minecraft.entity.Entity;

public class EventEntity$EventColision extends EventEntity {
  public double y;
  
  public double x;
  
  public double z;
  
  public void set_y(double paramDouble) {
    (give up)null;
    this.y = paramDouble;
  }
  
  public double get_x() {
    (give up)null;
    return this.x;
  }
  
  public double get_y() {
    (give up)null;
    return this.y;
  }
  
  public void set_x(double paramDouble) {
    (give up)null;
    this.x = paramDouble;
  }
  
  public EventEntity$EventColision(Entity paramEntity, double paramDouble1, double paramDouble2, double paramDouble3) {
    super(paramEntity);
    this.x = paramDouble1;
    this.y = paramDouble2;
    this.z = paramDouble3;
  }
  
  public double get_z() {
    (give up)null;
    return this.z;
  }
  
  public void set_z(double paramDouble) {
    (give up)null;
    this.z = this.z;
  }
}
