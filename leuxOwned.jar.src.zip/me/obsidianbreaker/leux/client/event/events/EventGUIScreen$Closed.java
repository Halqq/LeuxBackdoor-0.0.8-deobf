package me.obsidianbreaker.leux.client.event.events;

import net.minecraft.client.gui.GuiScreen;

public class EventGUIScreen$Closed extends EventGUIScreen {
  public EventGUIScreen$Closed(GuiScreen paramGuiScreen) {
    super(paramGuiScreen);
  }
}
