package me.obsidianbreaker.leux.client.event.events;

import net.minecraft.network.Packet;

public class EventPacket$ReceivePacket extends EventPacket {
  public EventPacket$ReceivePacket(Packet paramPacket) {
    super(paramPacket);
  }
}
