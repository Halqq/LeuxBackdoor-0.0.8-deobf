package me.obsidianbreaker.leux.client.event.events;

import give up;
import me.obsidianbreaker.leux.client.event.EventCancellable;
import net.minecraft.client.gui.GuiScreen;

public class EventGUIScreen extends EventCancellable {
  public GuiScreen guiscreen;
  
  public GuiScreen get_guiscreen() {
    (give up)null;
    return this.guiscreen;
  }
  
  public EventGUIScreen(GuiScreen paramGuiScreen) {
    this.guiscreen = paramGuiScreen;
  }
  
  public void set_screen(GuiScreen paramGuiScreen) {
    (give up)null;
    this.guiscreen = this.guiscreen;
  }
}
