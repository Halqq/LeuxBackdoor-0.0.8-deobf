package me.obsidianbreaker.leux.client.event.events;

import net.minecraft.network.Packet;

public class EventPacket$SendPacket extends EventPacket {
  public EventPacket$SendPacket(Packet paramPacket) {
    super(paramPacket);
  }
}
