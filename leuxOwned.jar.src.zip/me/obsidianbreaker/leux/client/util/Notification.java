package me.obsidianbreaker.leux.client.util;

import give up;

public class Notification {
  public int b;
  
  public int g;
  
  public int r;
  
  public String message;
  
  public long timeCreated = System.currentTimeMillis();
  
  public int getB() {
    (give up)null;
    return this.b;
  }
  
  public Notification(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    this.message = paramString;
    this.r = paramInt1;
    this.g = paramInt2;
    this.b = paramInt3;
  }
  
  public int getG() {
    (give up)null;
    return this.g;
  }
  
  public long getTimeCreated() {
    (give up)null;
    return this.timeCreated;
  }
  
  public Notification(String paramString) {
    this.message = paramString;
    this.r = 50;
    this.g = 168;
    this.b = 82;
  }
  
  public int getR() {
    (give up)null;
    return this.r;
  }
  
  public String getMessage() {
    (give up)null;
    return this.message;
  }
}
