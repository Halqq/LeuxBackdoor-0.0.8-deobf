package me.obsidianbreaker.leux.client.util;

import give up;
import java.util.Calendar;

public class TimeUtil {
  public static int get_day() {
    (give up)null;
    return Calendar.getInstance().get(5);
  }
  
  public static int get_second() {
    (give up)null;
    return Calendar.getInstance().get(13);
  }
  
  public static int get_hour() {
    (give up)null;
    return Calendar.getInstance().get(11);
  }
  
  public static int get_minuite() {
    (give up)null;
    return Calendar.getInstance().get(12);
  }
  
  public static int get_month() {
    (give up)null;
    return Calendar.getInstance().get(2);
  }
}
