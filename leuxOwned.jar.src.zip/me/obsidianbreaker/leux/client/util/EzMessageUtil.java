package me.obsidianbreaker.leux.client.util;

import give up;

public class EzMessageUtil {
  public static String message;
  
  public static String get_message() {
    (give up)null;
    return message;
  }
  
  public static void set_message(String paramString) {
    (give up)null;
    message = paramString;
  }
}
