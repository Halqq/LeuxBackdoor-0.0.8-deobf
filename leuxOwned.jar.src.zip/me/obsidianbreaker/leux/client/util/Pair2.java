package me.obsidianbreaker.leux.client.util;

import give up;

public class Pair2 {
  public Object first;
  
  public Object second;
  
  public Pair2(Object paramObject1, Object paramObject2) {
    this.first = paramObject1;
    this.second = paramObject2;
  }
  
  public Object getSecond() {
    (give up)null;
    return this.second;
  }
  
  public void setFirst(Object paramObject) {
    (give up)null;
    this.first = paramObject;
  }
  
  public void setSecond(Object paramObject) {
    (give up)null;
    this.second = paramObject;
  }
  
  public Object getFirst() {
    (give up)null;
    return this.first;
  }
}
