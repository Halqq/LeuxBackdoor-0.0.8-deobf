package me.obsidianbreaker.leux.client.util;

import give up;

public class Pair {
  public Object value;
  
  public Object key;
  
  public Object getValue() {
    (give up)null;
    return this.value;
  }
  
  public Pair(Object paramObject1, Object paramObject2) {
    this.key = paramObject1;
    this.value = paramObject2;
  }
  
  public Object getKey() {
    (give up)null;
    return this.key;
  }
  
  public void setKey(Object paramObject) {
    (give up)null;
    this.key = paramObject;
  }
  
  public void setValue(Object paramObject) {
    (give up)null;
    this.value = paramObject;
  }
}
