package me.obsidianbreaker.leux.client.util;

import give up;
import java.util.UUID;

public class EnemyUtil$Enemy {
  public UUID uuid;
  
  public String username;
  
  public EnemyUtil$Enemy(String paramString, UUID paramUUID) {
    this.username = paramString;
    this.uuid = paramUUID;
  }
  
  public String getUsername() {
    (give up)null;
    return this.username;
  }
}
