package me.obsidianbreaker.leux.client.util;

import give up;
import java.util.UUID;

public class FriendUtil$Friend {
  public UUID uuid;
  
  public String username;
  
  public FriendUtil$Friend(String paramString, UUID paramUUID) {
    this.username = paramString;
    this.uuid = paramUUID;
  }
  
  public String getUsername() {
    (give up)null;
    return this.username;
  }
  
  public UUID getUUID() {
    (give up)null;
    return this.uuid;
  }
}
