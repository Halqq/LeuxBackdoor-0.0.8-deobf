package me.obsidianbreaker.leux.client.util;

import give up;

public class ClientNameUtil {
  public static String message;
  
  public static String get_client_name() {
    (give up)null;
    return message;
  }
  
  public static void set_client_name(String paramString) {
    (give up)null;
    message = paramString;
  }
}
