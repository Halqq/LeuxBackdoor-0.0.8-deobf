package me.obsidianbreaker.leux.client.discordrpc;

import com.sun.jna.Callback;

public interface DiscordEventHandlers$OnGameUpdate extends Callback {
  void accept(String paramString);
}
