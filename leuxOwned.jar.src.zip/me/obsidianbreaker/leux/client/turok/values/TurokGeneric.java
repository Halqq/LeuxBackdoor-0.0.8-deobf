package me.obsidianbreaker.leux.client.turok.values;

import give up;

public class TurokGeneric {
  public Object value;
  
  public void set_value(Object paramObject) {
    (give up)null;
    this.value = paramObject;
  }
  
  public Object get_value() {
    (give up)null;
    return this.value;
  }
  
  public TurokGeneric(Object paramObject) {
    this.value = paramObject;
  }
}
