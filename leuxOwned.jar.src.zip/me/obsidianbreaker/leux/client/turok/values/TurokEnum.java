package me.obsidianbreaker.leux.client.turok.values;

public class TurokEnum {
  public Class value;
  
  public TurokEnum(Class paramClass) {
    this.value = paramClass;
  }
}
