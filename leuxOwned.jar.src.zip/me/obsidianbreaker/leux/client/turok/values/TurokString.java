package me.obsidianbreaker.leux.client.turok.values;

import give up;

public class TurokString {
  public String tag;
  
  public String value;
  
  public String name;
  
  public static String to_string(String paramString) {
    (give up)null;
    return paramString;
  }
  
  public void set_value(String paramString) {
    (give up)null;
    this.value = paramString;
  }
  
  public String get_value() {
    (give up)null;
    return this.value;
  }
  
  public static String to_string(float paramFloat) {
    (give up)null;
    return Float.toString(paramFloat);
  }
  
  public String get_name() {
    (give up)null;
    return this.name;
  }
  
  public String get_tag() {
    (give up)null;
    return this.tag;
  }
  
  public TurokString(String paramString1, String paramString2, String paramString3) {
    this.name = paramString1;
    this.tag = paramString2;
    this.value = paramString3;
  }
  
  public static String to_string(double paramDouble) {
    (give up)null;
    return Double.toString(paramDouble);
  }
  
  public static String to_string(int paramInt) {
    (give up)null;
    return Integer.toString(paramInt);
  }
  
  public static String to_string(boolean paramBoolean) {
    (give up)null;
    return Boolean.toString(paramBoolean);
  }
}
