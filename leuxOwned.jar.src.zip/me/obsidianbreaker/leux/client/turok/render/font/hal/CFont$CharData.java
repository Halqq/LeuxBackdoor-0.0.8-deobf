package me.obsidianbreaker.leux.client.turok.render.font.hal;

public class CFont$CharData {
  public int storedX;
  
  public int storedY;
  
  public int width;
  
  public CFont this$0;
  
  public int height;
}
