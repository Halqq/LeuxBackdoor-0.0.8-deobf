package me.obsidianbreaker.leux.client.turok.task;

import give up;

public class Font {
  public static String smoth(String paramString) {
    (give up)null;
    null = paramString;
    null = null.replace("a", "ᴀ");
    null = null.replace("b", "ʙ");
    null = null.replace("c", "ᴄ");
    null = null.replace("d", "ᴅ");
    null = null.replace("e", "ᴇ");
    null = null.replace("f", "ғ");
    null = null.replace("g", "ɢ");
    null = null.replace("h", "ʜ");
    null = null.replace("i", "ɪ");
    null = null.replace("j", "ᴊ");
    null = null.replace("k", "ᴋ");
    null = null.replace("l", "ʟ");
    null = null.replace("m", "ᴍ");
    null = null.replace("n", "ɴ");
    null = null.replace("o", "ᴏ");
    null = null.replace("p", "ᴘ");
    null = null.replace("q", "ǫ");
    null = null.replace("r", "ʀ");
    null = null.replace("s", "ѕ");
    null = null.replace("t", "ᴛ");
    null = null.replace("u", "ᴜ");
    null = null.replace("v", "ᴠ");
    null = null.replace("w", "ᴡ");
    null = null.replace("x", "х");
    null = null.replace("y", "ʏ");
    return null.replace("z", "ᴢ");
  }
}
