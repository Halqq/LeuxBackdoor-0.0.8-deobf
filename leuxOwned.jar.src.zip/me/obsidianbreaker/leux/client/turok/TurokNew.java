package me.obsidianbreaker.leux.client.turok;

import give up;

public class TurokNew {
  public static String VERSION;
  
  public static String AUTHOR = "SrRina";
  
  public static String NAME = "Turok Framework";
  
  public static String getAuthor() {
    (give up)null;
    return AUTHOR;
  }
  
  public static String getName() {
    (give up)null;
    return NAME;
  }
  
  public static String getVersion() {
    (give up)null;
    return VERSION;
  }
  
  static {
    VERSION = "4.5.5b";
  }
}
