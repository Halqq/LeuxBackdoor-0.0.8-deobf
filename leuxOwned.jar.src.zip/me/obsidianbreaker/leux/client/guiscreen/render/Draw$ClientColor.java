package me.obsidianbreaker.leux.client.guiscreen.render;

import give up;
import java.awt.Color;

public class Draw$ClientColor extends Color {
  public Draw$ClientColor(int paramInt1, int paramInt2, int paramInt3) {
    super(paramInt1, paramInt2, paramInt3);
  }
  
  public int hex() {
    (give up)null;
    return getRGB();
  }
  
  public Draw$ClientColor(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
}
