package me.obsidianbreaker.leux.client.guiscreen.render.components;

import give up;

public abstract class AbstractWidget {
  public int get_height() {
    (give up)null;
    return 0;
  }
  
  public int get_width() {
    (give up)null;
    return 0;
  }
  
  public void does_can(boolean paramBoolean) {
    (give up)null;
  }
  
  public int get_y() {
    (give up)null;
    return 0;
  }
  
  public void release(int paramInt1, int paramInt2, int paramInt3) {
    (give up)null;
  }
  
  public void mouse(int paramInt1, int paramInt2, int paramInt3) {
    (give up)null;
  }
  
  public void set_x(int paramInt) {
    (give up)null;
  }
  
  public boolean motion_pass(int paramInt1, int paramInt2) {
    (give up)null;
    return false;
  }
  
  public void set_width(int paramInt) {
    (give up)null;
  }
  
  public void bind(char paramChar, int paramInt) {
    (give up)null;
  }
  
  public void set_height(int paramInt) {
    (give up)null;
  }
  
  public int get_x() {
    (give up)null;
    return 0;
  }
  
  public void set_y(int paramInt) {
    (give up)null;
  }
  
  public boolean is_binding() {
    (give up)null;
    return false;
  }
  
  public void render(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = 2;
    (give up)null;
  }
}
