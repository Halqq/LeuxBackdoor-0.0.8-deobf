package me.obsidianbreaker.leux.client.guiscreen.render.font;

public class CFont$CharData {
  public int width;
  
  public int storedY;
  
  public CFont this$0;
  
  public int height;
  
  public int storedX;
}
