package me.zero.alpine.fork.listener;

public interface Listenable {}
