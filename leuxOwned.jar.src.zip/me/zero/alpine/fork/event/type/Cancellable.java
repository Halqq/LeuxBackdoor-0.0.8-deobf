package me.zero.alpine.fork.event.type;

import give up;

public class Cancellable implements ICancellable {
  public boolean cancelled;
  
  public boolean isCancelled() {
    (give up)null;
    return this.cancelled;
  }
  
  public void cancel() {
    (give up)null;
    this.cancelled = true;
  }
}
