package org.spongepowered.asm.mixin.gen;

class AccessorInfo$1 {
  static final int[] $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType = new int[(AccessorInfo$AccessorType.values()).length];
  
  static {
    $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_GETTER.ordinal()] = 1;
    $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_SETTER.ordinal()] = 2;
  }
}
