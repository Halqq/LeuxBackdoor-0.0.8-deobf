package org.spongepowered.asm.mixin.gen;

import java.util.Set;

enum AccessorInfo$AccessorType$3 {
  AccessorGenerator getGenerator(AccessorInfo paramAccessorInfo) {
    return new AccessorGeneratorMethodProxy(paramAccessorInfo);
  }
}
