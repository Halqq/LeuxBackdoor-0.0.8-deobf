package org.spongepowered.asm.mixin.injection.callback;

class CallbackInjector$1 {
  static final int[] $SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture = new int[(LocalCapture.values()).length];
  
  static {
    $SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture[LocalCapture.CAPTURE_FAILEXCEPTION.ordinal()] = 1;
    $SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture[LocalCapture.CAPTURE_FAILSOFT.ordinal()] = 2;
  }
}
