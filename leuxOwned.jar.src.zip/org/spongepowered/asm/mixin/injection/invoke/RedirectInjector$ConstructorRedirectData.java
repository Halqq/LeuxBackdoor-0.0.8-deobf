package org.spongepowered.asm.mixin.injection.invoke;

class RedirectInjector$ConstructorRedirectData {
  public static final String KEY = "ctor";
  
  public int injected = 0;
  
  final RedirectInjector this$0;
}
