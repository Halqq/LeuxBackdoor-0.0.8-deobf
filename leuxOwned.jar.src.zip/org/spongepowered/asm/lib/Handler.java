package org.spongepowered.asm.lib;

class Handler {
  Label start;
  
  Label end;
  
  Label handler;
  
  String desc;
  
  int type;
  
  Handler next;
  
  static Handler remove(Handler paramHandler, Label paramLabel1, Label paramLabel2) {
    return null;
  }
}
